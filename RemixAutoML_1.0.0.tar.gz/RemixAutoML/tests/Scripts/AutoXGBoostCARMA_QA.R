# Collection data.table
QA_Results <- data.table::CJ(
  Group = c(0,1,2,3),
  xregs = c(0,1,2,3),
  TOF = c(TRUE, FALSE),
  Trans = c(TRUE, FALSE),
  Diff = c(TRUE, FALSE))

# Other tests
QA_Results[, Success := 'Failure']
QA_Results[, Encoding := data.table::fifelse(runif(.N) < 0.5, "credibility", "binary")]
QA_Results[, Mixed := data.table::fifelse(runif(.N) < 0.5, TRUE, FALSE)]

FillNow = FALSE

# run = 103
# run = 39
# run = 101
# run = 128
for(run in seq_len(QA_Results[,.N])) {

  # Data ----
  if(QA_Results[run, Group] == 0L) {
    data <- RemixAutoML:::Post_Query_Helper('"nogroupevalwalmart.csv"')[['data']]
  } else if(QA_Results[run, Group] == 1L) {
    data <- RemixAutoML:::Post_Query_Helper('"onegroupevalwalmart.csv"')[['data']]
  } else if(QA_Results[run, Group] == 2L) {
    data <- RemixAutoML:::Post_Query_Helper('"twogroupevalwalmart.csv"')[['data']]
  } else if(QA_Results[run, Group] == 3L) {
    data <- RemixAutoML:::Post_Query_Helper('"threegroupevalwalmart.csv"')[['data']]
  }

  if(!FillNow && QA_Results[run, Group] == 3L) {

    # Unequal Start Dates
    data[Region == 'A' & Date < "2010-05-05", ID := 'REMOVE']
    data[is.na(ID), ID := 'KEEP']
    data <- data[ID == 'KEEP'][, ID := NULL]

    data[Region == 'A' & Date > "2011-11-30", ID := 'REMOVE']
    data[is.na(ID), ID := 'KEEP']
    data <- data[ID == 'KEEP'][, ID := NULL]
  }

  # xregs
  if(QA_Results[run, xregs] == 0L) {
    xregs <- NULL
  } else if(QA_Results[run, xregs] == 1L) {
    if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg1.csv"')[['data']]
    if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg1.csv"')[['data']]
    if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg1.csv"')[['data']]
    if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg1.csv"')[['data']]
  } else if(QA_Results[run, xregs] == 2L) {
    if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg2.csv"')[['data']]
    if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg2.csv"')[['data']]
    if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg2.csv"')[['data']]
    if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg2.csv"')[['data']]
  } else if(QA_Results[run, xregs] == 3L) {
    if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg3.csv"')[['data']]
    if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg3.csv"')[['data']]
    if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg3.csv"')[['data']]
    if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg3.csv"')[['data']]
  }

  # Testing params
  TOF <- QA_Results[run, TOF]
  Trans <- QA_Results[run, Trans]
  Diff <- QA_Results[run, Diff]
  if(QA_Results[run, Group] == 0L) {
    groupvariables <- NULL
  } else if(QA_Results[run, Group] == 1L) {
    groupvariables <- 'Dept'
  } else if(QA_Results[run, Group] == 2L) {
    groupvariables <- c('Store','Dept')
  } else if(QA_Results[run, Group] == 3L) {
    groupvariables <- c('Region','Store','Dept')
  }

  # Ensure series have no missing dates (also remove series with more than 25% missing values)
  data <- RemixAutoML::TimeSeriesFill(
    data,
    DateColumnName = 'Date',
    GroupVariables = groupvariables,
    TimeUnit = 'weeks',
    FillType = if(length(groupvariables) > 0L) "dynamic:target_encoding" else 'maxmax',
    MaxMissingPercent = 0.25,
    SimpleImpute = TRUE)


  # Set negative numbers to 0
  data <- data[, Weekly_Sales := data.table::fifelse(Weekly_Sales < 0, 0, Weekly_Sales)]

  # Ensure series have no missing dates (also remove series with more than 25% missing values)
  if(QA_Results[run, xregs] != 0L) {
    xregs <- RemixAutoML::TimeSeriesFill(
      xregs,
      DateColumnName = 'Date',
      GroupVariables = groupvariables,
      TimeUnit = 'weeks',
      FillType = 'maxmax',
      MaxMissingPercent = 0.25,
      SimpleImpute = TRUE)
  }

  # Copy data
  data1 <- data.table::copy(data)
  if(QA_Results[run, xregs] != 0L) xregs1 <- data.table::copy(xregs) else xregs1 <- NULL

  # Build forecast ----
  TestModel <- tryCatch({RemixAutoML::AutoXGBoostCARMA(

    # Data Artifacts
    data = data1,
    XREGS = xregs1,
    NonNegativePred = FALSE,
    RoundPreds = FALSE,
    TargetColumnName = 'Weekly_Sales',
    DateColumnName = 'Date',
    HierarchGroups = NULL,
    GroupVariables = groupvariables,
    TimeUnit = 'weeks',
    TimeGroups = c('weeks','months'),

    # Data Wrangling Features
    ZeroPadSeries = "dynamic:meow",
    TimeWeights = 0.999,
    EncodingMethod = 'meow',
    DataTruncate = FALSE,
    SplitRatios = c(1 - 10 / 100, 10 / 100),
    PartitionType = 'random',
    AnomalyDetection = NULL,

    # Productionize
    FC_Periods = 4,
    TrainOnFull = TOF,
    NThreads = 64,
    Timer = TRUE,
    DebugMode = TRUE,
    SaveDataPath = getwd(),

    # Target Transformations
    TargetTransformation = Trans,
    Methods = 'Asinh',
    Difference = Diff,

    # Features
    Lags = NULL,#c(1:5),
    MA_Periods = NULL,# c(2:5),
    SD_Periods = NULL,
    Skew_Periods = NULL,
    Kurt_Periods = NULL,
    Quantile_Periods = NULL,
    HolidayLags = 1,
    HolidayMovingAverages = NULL,#1:2,
    Quantiles_Selected = c('q5','q95'),
    FourierTerms = 0,
    CalendarVariables = c('week','wom','month','quarter'),
    HolidayVariable = c('USPublicHolidays','EasterGroup','ChristmasGroup','OtherEcclesticalFeasts'),
    HolidayLookback = 7,
    TimeTrendVariable = TRUE,

    # ML evaluation args
    TreeMethod = 'hist',
    EvalMetric = 'RMSE',
    LossFunction = 'reg:squarederror',

    # ML grid tuning args
    MaxRunsWithoutNewWinner = 30L,
    MaxRunMinutes = 30,
    GridTune = FALSE,
    ModelCount = 5,
    GridEvalMetric = 'mse',

    alpha = 0,
    lambda = 1,
    SaveModel = FALSE,
    ArgsList = NULL,
    ModelID = "FC001",
    TVT = NULL,

    # ML args
    NTrees = 50,
    LearningRate = 0.03,
    MaxDepth = 4L,
    MinChildWeight = 1.0,
    SubSample = 1.0,
    ColSampleByTree = 1.0)}, error = function(x) NULL)

  # Outcome
  if(!is.null(TestModel)) QA_Results[run, Success := 'Success']
  rm(TestModel)
  RemixAutoML:::Post_Append_Helper(QA_Results,'AutoXGBoostCARMA_QA')
  Sys.sleep(5)
}

# Defaults ----


# Collection data.table
QA_Results <- data.table::CJ(
  Group = c(0,1,2,3),
  xregs = c(0,1,2,3),
  TOF = c(TRUE, FALSE),
  Trans = c(TRUE, FALSE),
  Diff = c(TRUE, FALSE))

# Other tests
QA_Results[, Success := 'Failure']
QA_Results[, Encoding := data.table::fifelse(runif(.N) < 0.5, "credibility", "binary")]
QA_Results[, Mixed := data.table::fifelse(runif(.N) < 0.5, TRUE, FALSE)]


library(RemixAutoML)
library(data.table)
library(lubridate)

source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/MiscFunctions.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/XGBoostHelpers.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/ModelMetrics.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/CARMA-HelperFunctions.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_CalendarTypes.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_CharacterTypes.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_CrossRowOperations.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_NumericTypes.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_DataSets.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/FeatureEngineering_ModelBased.R'))
source(file.path('C:/Users/Bizon/Documents/GitHub/RemixAutoML/R/ModelEvaluationPlots.R'))

# run = 37
# run = 38
# run = 39
run = 103

# Data
if(QA_Results[run, Group] == 0L) {
  data <- RemixAutoML:::Post_Query_Helper('"nogroupevalwalmart.csv"')[['data']]
} else if(QA_Results[run, Group] == 1L) {
  data <- RemixAutoML:::Post_Query_Helper('"onegroupevalwalmart.csv"')[['data']]
} else if(QA_Results[run, Group] == 2L) {
  data <- RemixAutoML:::Post_Query_Helper('"twogroupevalwalmart.csv"')[['data']]
} else if(QA_Results[run, Group] == 3L) {
  data <- RemixAutoML:::Post_Query_Helper('"threegroupevalwalmart.csv"')[['data']]
}


  # Unequal Start Dates
if(QA_Results[run, Group] > 0L) {
  data[Region == 'A' & Date < "2010-05-05", ID := 'REMOVE']
  data[is.na(ID), ID := 'KEEP']
  data <- data[ID == 'KEEP'][, ID := NULL]

  data[Region == 'A' & Date > "2011-11-30", ID := 'REMOVE']
  data[is.na(ID), ID := 'KEEP']
  data <- data[ID == 'KEEP'][, ID := NULL]
}

# xregs
if(QA_Results[run, xregs] == 0L) {
  xregs <- NULL
} else if(QA_Results[run, xregs] == 1L) {
  if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg1.csv"')[['data']]
  if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg1.csv"')[['data']]
  if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg1.csv"')[['data']]
  if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg1.csv"')[['data']]
} else if(QA_Results[run, xregs] == 2L) {
  if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg2.csv"')[['data']]
  if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg2.csv"')[['data']]
  if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg2.csv"')[['data']]
  if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg2.csv"')[['data']]
} else if(QA_Results[run, xregs] == 3L) {
  if(QA_Results[run, Group] == 0L) xregs <- RemixAutoML:::Post_Query_Helper('"nogroupfcwalmartxreg3.csv"')[['data']]
  if(QA_Results[run, Group] == 1L) xregs <- RemixAutoML:::Post_Query_Helper('"onegroupfcwalmartxreg3.csv"')[['data']]
  if(QA_Results[run, Group] == 2L) xregs <- RemixAutoML:::Post_Query_Helper('"twogroupfcwalmartxreg3.csv"')[['data']]
  if(QA_Results[run, Group] == 3L) xregs <- RemixAutoML:::Post_Query_Helper('"threegroupfcwalmartxreg3.csv"')[['data']]
}

# Testing params
TOF <- QA_Results[run, TOF]
Trans <- QA_Results[run, Trans]
Diff <- QA_Results[run, Diff]
if(QA_Results[run, Group] == 0L) {
  groupvariables <- NULL
} else if(QA_Results[run, Group] == 1L) {
  groupvariables <- 'Dept'
} else if(QA_Results[run, Group] == 2L) {
  groupvariables <- c('Store','Dept')
} else if(QA_Results[run, Group] == 3L) {
  groupvariables <- c('Region','Store','Dept')
}

# Ensure series have no missing dates (also remove series with more than 25% missing values)
# data <- RemixAutoML::TimeSeriesFill(
#   data,
#   DateColumnName = 'Date',
#   GroupVariables = groupvariables,
#   TimeUnit = 'weeks',
#   FillType = 'dynamic:meow',
#   MaxMissingPercent = 0.25,
#   SimpleImpute = TRUE)

# Set negative numbers to 0
data <- data[, Weekly_Sales := data.table::fifelse(Weekly_Sales < 0, 0, Weekly_Sales)]

# Ensure series have no missing dates (also remove series with more than 25% missing values)
# if(QA_Results[run, xregs] != 0L) {
#   xregs <- RemixAutoML::TimeSeriesFill(
#     xregs,
#     DateColumnName = 'Date',
#     GroupVariables = groupvariables,
#     TimeUnit = 'weeks',
#     FillType = 'maxmax',
#     MaxMissingPercent = 0.25,
#     SimpleImpute = TRUE)
# }

# Copy data
data1 <- data.table::copy(data)
if(QA_Results[run, xregs] != 0L) xregs1 <- data.table::copy(xregs) else xregs1 <- NULL

# Copy data
SaveModel = FALSE
ArgsList = NULL

data1 <- data1
XREGS <- xregs1
NonNegativePred = FALSE
RoundPreds = FALSE
TargetColumnName = 'Weekly_Sales'
DateColumnName = 'Date'
HierarchGroups = NULL
GroupVariables = groupvariables
TimeUnit = 'weeks'
TimeGroups = c('weeks','months')
EncodingMethod = 'target_encoding'
ZeroPadSeries = 'dynamic:target_encoding'
DataTruncate = FALSE
SplitRatios = c(0.95,0.05)
PartitionType = 'random'
AnomalyDetection = NULL
FC_Periods = 1
TimeWeights = 0.999
TrainOnFull = TOF
NThreads = 8
Timer = TRUE
DebugMode = TRUE
SaveDataPath = getwd()
PDFOutputPath = getwd()
TargetTransformation = Trans
Methods = 'Asinh'
Difference = Diff
Lags = NULL # 1
MA_Periods = NULL #list('weeks' = c(2:5), 'months' = c(2,3))
SD_Periods = NULL
Skew_Periods = NULL
Kurt_Periods = NULL
Quantile_Periods = c('q5','q95')
HolidayLags = 1
HolidayMovingAverages = NULL #1:2
Quantiles_Selected = NULL
FourierTerms = 0
CalendarVariables = NULL # c('week', 'wom', 'month', 'quarter')
HolidayVariable = NULL # c('USPublicHolidays','EasterGroup', 'ChristmasGroup','OtherEcclesticalFeasts')
HolidayLookback <- 7
TimeTrendVariable = FALSE # TRUE
TreeMethod = 'hist'
EvalMetric = 'RMSE'
LossFunction = 'reg:squarederror'
MaxRunsWithoutNewWinner = 30L
MaxRunMinutes = 30
GridTune = FALSE
ModelCount = 5
GridEvalMetric = 'mse'
NTrees = 50
LearningRate = 0.03
MaxDepth = 9L
MinChildWeight = 1.0
SubSample = 1.0
ColSampleByTree = 1.0
alpha = 0
lambda = 1
SaveModel = FALSE
ArgsList = NULL
ModelID = "FC001"
TVT = NULL

# Differencing ----
# GroupVariables.=GroupVariables
# Difference.=Difference
# data.=data
# TargetColumnName.=TargetColumnName
# FC_Periods.=FC_Periods

# DifferenceData ----
# data = data.
# ColumnsToDiff = eval(TargetColumnName.)
# CARMA = TRUE
# TargetVariable = eval(TargetColumnName.)
# GroupingVariable = NULL

# Rolling Stats ----
# data.=data
# TargetColumnName.=TargetColumnName
# DateColumnName.=DateColumnName
# GroupVariables.=GroupVariables
# HierarchGroups.=HierarchGroups
# Difference.=Difference
# TimeGroups.=TimeGroups
# TimeUnit.=TimeUnit
# Lags.=Lags
# MA_Periods.=MA_Periods
# SD_Periods.=SD_Periods
# Skew_Periods.=Skew_Periods
# Kurt_Periods.=Kurt_Periods
# Quantile_Periods.=Quantile_Periods
# Quantiles_Selected.=Quantiles_Selected
# HolidayVariable.=HolidayVariable
# HolidayLags.=HolidayLags
# HolidayMovingAverages.=HolidayMovingAverages
# DebugMode.=DebugMode

# AutoLagRollStats ----
# data = data.
# DateColumn = eval(DateColumnName.)
# Targets = eval(TargetColumnName.)
# HierarchyGroups = NULL
# IndependentGroups = NULL
# TimeBetween = NULL
# TimeUnit = TimeUnit.
# TimeUnitAgg = TimeUnit.
# TimeGroups = TimeGroups.
# RollOnLag1 = TRUE
# Type = 'Lag'
# SimpleImpute = TRUE
# Lags = Lags.
# MA_RollWindows = MA_Periods.
# SD_RollWindows = SD_Periods.
# Skew_RollWindows = Skew_Periods.
# Kurt_RollWindows = Kurt_Periods.
# Quantile_RollWindows = Quantile_Periods.
# Quantiles_Selected = Quantiles_Selected.
# Debug = DebugMode.

# Rolling stats update ----
# ModelType='xgboost'
# DebugMode.=DebugMode
# UpdateData.=UpdateData
# GroupVariables.=GroupVariables
# Difference.=Difference
# CalendarVariables.=CalendarVariables
# HolidayVariable.=HolidayVariable
# IndepVarPassTRUE.=IndepentVariablesPass
# data.=data
# CalendarFeatures.=CalendarFeatures
# XREGS.=XREGS
# HierarchGroups.=HierarchGroups
# GroupVarVector.=GroupVarVector
# TargetColumnName.=TargetColumnName
# DateColumnName.=DateColumnName
# Preds.=NULL
# HierarchSupplyValue.=HierarchSupplyValue
# IndependentSupplyValue.=IndependentSupplyValue
# TimeUnit.=TimeUnit
# TimeGroups.=TimeGroups
# Lags.=Lags
# MA_Periods.=MA_Periods
# SD_Periods.=SD_Periods
# Skew_Periods.=Skew_Periods
# Kurt_Periods.=Kurt_Periods
# Quantile_Periods.=Quantile_Periods
# Quantiles_Selected.=Quantiles_Selected
# HolidayLags.=HolidayLags
# HolidayMovingAverages.=HolidayMovingAverages

# CarmaUpdateVars ----
# IndepVarPassTRUE=NULL
# data.
# UpdateData.
# CalendarFeatures.
# XREGS.
# Difference.
# HierarchGroups.
# GroupVariables.
# GroupVarVector.
# CalendarVariables=CalVar
# HolidayVariable=HolVar
# TargetColumnName.
# DateColumnName.

# CarmaScore ----
i = 1
Type = 'xgboost'
i.=i
N.=N
EncodingMethod. = EncodingMethod
GroupVariables.=GroupVariables
ModelFeatures.=ModelFeatures
HierarchGroups.=HierarchGroups
DateColumnName.=DateColumnName
Difference.=Difference
TargetColumnName.=TargetColumnName
Step1SCore.=Step1SCore
Model.=Model
FutureDateData.=FutureDateData
NonNegativePred.=NonNegativePred
RoundPreds.=RoundPreds
UpdateData.= if(i == 1) NULL else UpdateData
FactorList.=TestModel$FactorLevelsList
Debug = TRUE

# XGBoost Scoring ----
# i == 1
# TargetType = 'regression'
# ScoringData = Step1SCore.
# FeatureColumnNames = ModelFeatures.
# OneHot = FALSE
# IDcols = IDcols
# ModelObject = Model.
# EncodingMethod = EncodingMethod.
# ModelPath = getwd()
# ModelID = 'ModelTest'
# ReturnFeatures = TRUE
# TransformNumeric = FALSE
# BackTransNumeric = FALSE
# TargetColumnName = NULL
# TransformationObject = NULL
# FactorLevelsList = FactorList.
# TransID = NULL
# TransPath = NULL
# MDP_Impute = TRUE
# MDP_CharToFactor = TRUE
# MDP_RemoveDates = TRUE
# MDP_MissFactor = '0'
# MDP_MissNum = -1

# Categorical encoding ----
# data=ScoringData
# ML_Type=TargetType
# GroupVariables=names(FactorLevelsList)
# TargetVariable=NULL
# Method=EncodingMethod
# SavePath=model_path.
# Scoring=TRUE
# ImputeValueScoring=0
# ReturnFactorLevelList=FALSE
# SupplyFactorLevelList=FactorLevelsList
# KeepOriginalFactors=FALSE

# Regression ----
OutputSelection = c('Importances', 'EvalPlots', 'EvalMetrics', 'Score_TrainData')
WeightsColumnName = NULL
TreeMethod = TreeMethod
NThreads = NThreads
model_path = getwd()
metadata_path = if(!is.null(PDFOutputPath)) PDFOutputPath else getwd()
ModelID = 'XGBoost'
ReturnFactorLevels = TRUE
ReturnModelObjects = TRUE
SaveModelObjects = FALSE
SaveInfoToPDF = if(!is.null(PDFOutputPath)) TRUE else FALSE
data = train
TrainOnFull = TrainOnFull
ValidationData = valid
TestData = test
TargetColumnName = TargetVariable
FeatureColNames = ModelFeatures
IDcols = IDcols
TransformNumericColumns = NULL
Methods = NULL
LossFunction = LossFunction
eval_metric = EvalMetric
NumOfParDepPlots = 10
PassInGrid = NULL
GridTune = GridTune
grid_eval_metric = GridEvalMetric
BaselineComparison = 'default'
MaxModelsInGrid = ModelCount
MaxRunsWithoutNewWinner = MaxRunsWithoutNewWinner
MaxRunMinutes = MaxRunMinutes
Verbose = 1L
Trees = NTrees
eta = LearningRate
max_depth = MaxDepth
min_child_weight = MinChildWeight
subsample = SubSample
colsample_bytree = ColSampleByTree

# Data Prep ----
ModelType='regression'
data.=data
ValidationData.=ValidationData
TestData.=TestData
TargetColumnName.=TargetColumnName
FeatureColNames.=FeatureColNames
WeightsColumnName.=WeightsColumnName
IDcols.=IDcols
TransformNumericColumns.=TransformNumericColumns
Methods.=Methods
ModelID.=ModelID
model_path.=model_path
TrainOnFull.=TrainOnFull
SaveModelObjects.=SaveModelObjects
ReturnFactorLevels.=ReturnFactorLevels
EncodingMethod.=EncodingMethod

# Binary Encoding issue ----
# RunMode='train'
# ModelType=ModelType
# TrainData=dataTrain
# ValidationData=dataTest
# TestData=TestData.
# TargetVariableName=TargetColumnName.
# CategoricalVariableNames=CatFeatures
# EncodeMethod=EncodingMethod.
# KeepCategoricalVariables=FALSE
# ReturnMetaData=TRUE
# MetaDataPath=model_path.
# MetaDataList=NULL
# ImputeMissingValue=0

# Train Validation Data ----
# model.=model
# TestData.=NULL
# ModelType='regression'
# TrainOnFull.=TRUE
# TestDataCheck=FALSE
# FinalTestTarget.=FinalTestTarget
# TestTarget.=TestTarget
# TrainTarget.=TrainTarget
# TrainMerge.=TrainMerge
# TestMerge.=TestMerge
# dataTest.=dataTest
# data.=dataTrain
# predict.=predict
# TargetColumnName.=TargetColumnName
# SaveModelObjects. = SaveModelObjects
# metadata_path.=metadata_path
# model_path.=model_path
# ModelID.=ModelID
# LossFunction.=NULL
# TransformNumericColumns.=TransformNumericColumns
# GridTune.=GridTune
# TransformationResults.=TransformationResults
# TargetLevels.=NULL

# Validation Data ----
# ModelType='regression'
# TestDataCheck=!is.null(TestData)
# TrainOnFull.=TrainOnFull
# model.=model
# TargetColumnName.=TargetColumnName
# SaveModelObjects.=SaveModelObjects
# metadata_path.=metadata_path
# model_path.=model_path
# ModelID.=ModelID
# TestData.=TestData
# TestTarget.=TestTarget
# FinalTestTarget.=FinalTestTarget
# TestMerge.=TestMerge
# dataTest.=dataTest
# TrainTarget.=TrainTarget
# predict.=predict
# TransformNumericColumns.=TransformNumericColumns
# TransformationResults.=TransformationResults
# GridTune.=GridTune
# data.=dataTrain

# Eval Plots Validation ----
# ModelType='regression'
# TrainOnFull.=TrainOnFull
# ValidationData.=ValidationData
# NumOfParDepPlots.=NumOfParDepPlots
# VariableImportance.=VariableImportance
# TargetColumnName.=TargetColumnName
# FeatureColNames.=FeatureColNames
# SaveModelObjects.=SaveModelObjects
# ModelID.=ModelID
# metadata_path.=metadata_path
# model_path.=model_path
# LossFunction.='RMSE'
# EvalMetric.=NULL
# EvaluationMetrics.=EvalMetricsList
# predict.=NULL

# Return Data Prep ----
# UpdateData.=UpdateData
# FutureDateData.=FutureDateData
# dataStart.=dataStart
# DateColumnName.=DateColumnName
# TargetColumnName.=TargetColumnName
# GroupVariables.=GroupVariables
# Difference.=Difference
# TargetTransformation.=TargetTransformation
# TransformObject.=TransformObject
# NonNegativePred.=NonNegativePred
# DiffTrainOutput. = NULL

# DiffernceDataReverse ----
# data = UpdateData.
# ScoreData = NULL
# CARMA = TRUE
# TargetCol = eval(TargetColumnName.)
# FirstRow = DiffTrainOutput.$FirstRow[[eval(TargetColumnName.)]]
# LastRow = NULL

# Update Features ----
# UpdateData.=UpdateData
# GroupVariables.=GroupVariables
# CalendarFeatures.=CalendarFeatures
# CalendarVariables.=CalendarVariables
# GroupVarVector.=GroupVarVector
# DateColumnName.=DateColumnName
# XREGS.=XREGS
# FourierTerms.=FourierTerms
# FourierFC.=FourierFC
# TimeGroups.=TimeGroups
# TimeTrendVariable.=TimeTrendVariable
# N.=N
# TargetColumnName.=TargetColumnName
# HolidayVariable.=HolidayVariable
# HolidayLookback.=HolidayLookback
# TimeUnit.=TimeUnit
# AnomalyDetection.=AnomalyDetection
# i.=i

